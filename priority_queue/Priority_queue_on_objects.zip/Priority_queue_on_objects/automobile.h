#include "AutoMobileType.h"
#include<string>
#include <iostream>
class AutoMobile
{
private:
    std::string _id;
    float _price;
    AutomobileType _type;
public:
    /*special member functions*/
    AutoMobile()=delete;
    ~AutoMobile()=default;
    AutoMobile(const AutoMobile &)=default;
    AutoMobile(AutoMobile &&)=default;
    AutoMobile & operator=(const AutoMobile &)=delete;
    AutoMobile & operator=(AutoMobile &&)=default;

    AutoMobile(std::string id,float price,AutomobileType type);
    bool operator<(const AutoMobile & _auto);
    float price() const { return _price; }
    bool operator()(const AutoMobile & _autoMobile);
    friend std::ostream &operator<<(std::ostream &os, const AutoMobile &rhs);
    
};

