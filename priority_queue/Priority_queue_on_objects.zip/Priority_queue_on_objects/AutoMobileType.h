enum class AutomobileType
{
    PRIVATE,
    PUBLIC
};