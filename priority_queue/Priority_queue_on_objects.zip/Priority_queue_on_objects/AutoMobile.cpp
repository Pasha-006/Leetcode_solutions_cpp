#include "automobile.h"
std::ostream &operator<<(std::ostream &os, const AutoMobile &rhs) {
std::cout<<"------------------------------------------------------------"<<std::endl;
    os << "_id: " << rhs._id
       << " _price: " << rhs._price
       << " _type: " <<(int) rhs._type;
    return os;
}
AutoMobile::AutoMobile(std::string id, float price, AutomobileType type)
:_id(id),_price(price),_type(type)
{
}
bool AutoMobile::operator<(const AutoMobile &_auto)
{
    return this->price()<_auto.price();
}
bool AutoMobile::operator()(const AutoMobile &_autoMobile)
{
    return _price<_autoMobile._price;
}