#include "automobile.h"
#include<queue>
struct PriceCompare 
{
    bool operator()(const AutoMobile & _autoMobile1,const AutoMobile &_autoMobile2)
    {
        return _autoMobile1.price()<_autoMobile2.price();
    }

};
int main()
{
    std::priority_queue<AutoMobile,std::vector<AutoMobile>,PriceCompare> pq;
   // std::priority_queue<AutoMobile> pq;
    pq.push(AutoMobile("1",34000,AutomobileType::PRIVATE));
    pq.push(AutoMobile("2",50000,AutomobileType::PUBLIC));
    pq.push(AutoMobile("3",3000,AutomobileType::PRIVATE));
    pq.push(AutoMobile("4",70000,AutomobileType::PUBLIC));
    while(!pq.empty())
    {
        std::cout<<pq.top()<<std::endl;
        pq.pop();
    }
    return 0;
}